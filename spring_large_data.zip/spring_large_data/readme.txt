如果直接调用查询方法，然后把数据写入到excel的时候，数据量大的时候很容易系统异常或者内存溢出，所以改用了mybaits 流式查询的方式。在service 方法中有对比，可以试试。

我测试的是数据量是100万行，每行20个字段。

访问地址：http://localhost:8080/export



-- mp.tbl_employee definition
CREATE TABLE `tbl_employee` (
  `last_name` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gender` char(1) CHARACTER SET utf8mb4 DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `Column1` varchar(100) DEFAULT NULL,
  `Column2` varchar(100) DEFAULT NULL,
  `Column3` varchar(100) DEFAULT NULL,
  `Column4` varchar(100) DEFAULT NULL,
  `Column5` varchar(100) DEFAULT NULL,
  `Column6` varchar(100) DEFAULT NULL,
  `Column7` varchar(100) DEFAULT NULL,
  `Column8` varchar(100) DEFAULT NULL,
  `Column9` varchar(100) DEFAULT NULL,
  `Column10` varchar(100) DEFAULT NULL,
  `Column11` varchar(100) DEFAULT NULL,
  `Column12` varchar(100) DEFAULT NULL,
  `Column13` varchar(100) DEFAULT NULL,
  `Column14` varchar(100) DEFAULT NULL,
  `Column15` varchar(100) DEFAULT NULL,
  `Column16` varchar(100) DEFAULT NULL,
  `Column17` varchar(100) DEFAULT NULL,
  `Column18` varchar(100) DEFAULT NULL,
  `createtime` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2245714 DEFAULT CHARSET=utf8;