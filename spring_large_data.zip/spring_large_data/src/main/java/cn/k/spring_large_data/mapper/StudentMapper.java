package cn.k.spring_large_data.mapper;

import cn.k.spring_large_data.domain.StudentDomain;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.cursor.Cursor;

import java.util.List;

@Mapper
public interface StudentMapper {
  /**
   * mybatis流式查询
   * @return
   */
  Cursor<StudentDomain> exportByCondition();

  /**
   * 普通查询，方便对比
   */
//  List<StudentDomain> exportByCondition();
}