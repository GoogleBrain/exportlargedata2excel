package cn.k.spring_large_data.controller;

import cn.k.spring_large_data.service.RecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@RestController
@Slf4j
public class ExportLargeDataToExcelController {

    @Resource
    private RecordService recordService;

    @RequestMapping(value = "/export", method = RequestMethod.GET)
    public void export(HttpServletResponse response) throws Exception {
        try {
            List<String> titleList = Arrays.asList("序号", "名字", "邮箱", "性别", "年龄", "列1", "列2", "列3", "列4", "列5", "列6", "列7", "列8", "列9", "列10", "列11", "列12", "列13", "列14", "列15", "列16", "列17", "列18");
            recordService.uploadExcelAboutUser(response, "项目信息.xlsx", titleList);
        } catch (Throwable e) {
            log.error("导出数据系统异常,req={}", e);
            throw e;
        }

    }
}