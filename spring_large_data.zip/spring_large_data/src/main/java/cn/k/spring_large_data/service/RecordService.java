package cn.k.spring_large_data.service;

import cn.k.spring_large_data.domain.StudentDomain;
import cn.k.spring_large_data.mapper.StudentMapper;
import lombok.extern.java.Log;
import org.apache.ibatis.cursor.Cursor;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

@Log
@Service
public class RecordService {

    @Resource
    private SqlSessionFactory sqlSessionFactory;


    @Resource
    private StudentMapper studentMapper;

    /**
     * 用户信息导出类
     *
     * @param response   响应
     * @param fileName   文件名
     * @param columnList 每列的标题名
     */
    public void uploadExcelAboutUser(HttpServletResponse response, String fileName, List<String> columnList) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        //声明输出流
        OutputStream os = null;
        //设置响应头
        setResponseHeader(response, fileName);
        try {
            //获取输出流
            os = response.getOutputStream();
            //内存中保留1000条数据，以免内存溢出，其余写入硬盘
            SXSSFWorkbook wb = new SXSSFWorkbook(1000);
            //获取该工作区的第一个sheet
            Sheet sheet1 = wb.createSheet("sheet1");
            final int[] excelRow = {0};
            //创建标题行
            Row titleRow = sheet1.createRow(excelRow[0]++);
            for (int i = 0; i < columnList.size(); i++) {
                //创建该行下的每一列，并写入标题数据
                Cell cell = titleRow.createCell(i);
                cell.setCellValue(columnList.get(i));
            }
            /**
             * 采用流式查询方式进行数据的查询，这样不会导致内存溢出。
             */
            try (Cursor<StudentDomain> cursor = sqlSession.getMapper(StudentMapper.class).exportByCondition()) { // 1
                cursor.forEach(stu -> {
                        Row dataRow = sheet1.createRow(excelRow[0]++);
                        //内层for循环创建每行对应的列，并赋值
                        int count = 1;
                        for (int j = 0; j <=22; j++) {//由于多了一列序号列所以内层循环从-1开始
                            Cell cell = dataRow.createCell(j);
                            if (j == 0) {//第一列是序号列，不是在数据库中读取的数据，因此手动递增赋值
                                cell.setCellValue(stu.getId());
                            } else if (j == 1) {
                                cell.setCellValue(stu.getLastName());
                            } else if (j == 2) {
                                cell.setCellValue(stu.getEmail());
                            } else if (j == 3) {
                                cell.setCellValue(stu.getGender());
                            } else if (j ==4) {
                                cell.setCellValue(stu.getAge());
                            } else if (j ==5) {
                                cell.setCellValue(stu.getC1());
                            } else if (j ==6) {
                                cell.setCellValue(stu.getC2());
                            } else if (j ==7) {
                                cell.setCellValue(stu.getC3());
                            } else if (j ==8) {
                                cell.setCellValue(stu.getC4());
                            } else if (j ==9) {
                                cell.setCellValue(stu.getC5());
                            } else if (j ==10) {
                                cell.setCellValue(stu.getC6());
                            } else if (j ==11) {
                                cell.setCellValue(stu.getC7());
                            } else if (j ==12) {
                                cell.setCellValue(stu.getC8());
                            } else if (j ==13) {
                                cell.setCellValue(stu.getC9());
                            } else if (j ==14) {
                                cell.setCellValue(stu.getC10());
                            } else if (j ==15) {
                                cell.setCellValue(stu.getC11());
                            } else if (j ==16) {
                                cell.setCellValue(stu.getC12());
                            } else if (j ==17) {
                                cell.setCellValue(stu.getC13());
                            } else if (j ==18) {
                                cell.setCellValue(stu.getC14());
                            } else if (j ==19) {
                                cell.setCellValue(stu.getC15());
                            } else if (j ==20) {
                                cell.setCellValue(stu.getC16());
                            } else if (j ==21) {
                                cell.setCellValue(stu.getC17());
                            } else if (j ==22) {
                                cell.setCellValue(stu.getC18());
                            }
                        }
                });
            }

            /**
             * 普通方式，容易内存溢出
             */
//            List<Student> students = studentMapper.exportByCondition();
//            for(Student stu:students){
//                        Row dataRow = sheet1.createRow(excelRow[0]++);
//                        //内层for循环创建每行对应的列，并赋值
//                        int count = 1;
//                        for (int j = 0; j <=22; j++) {//由于多了一列序号列所以内层循环从-1开始
//                            Cell cell = dataRow.createCell(j);
//                            if (j == 0) {//第一列是序号列，不是在数据库中读取的数据，因此手动递增赋值
//                                cell.setCellValue(stu.getId());
//                            } else if (j == 1) {
//                                cell.setCellValue(stu.getLastName());
//                            } else if (j == 2) {
//                                cell.setCellValue(stu.getEmail());
//                            } else if (j == 3) {
//                                cell.setCellValue(stu.getGender());
//                            } else if (j ==4) {
//                                cell.setCellValue(stu.getAge());
//                            } else if (j ==5) {
//                                cell.setCellValue(stu.getC1());
//                            } else if (j ==6) {
//                                cell.setCellValue(stu.getC2());
//                            } else if (j ==7) {
//                                cell.setCellValue(stu.getC3());
//                            } else if (j ==8) {
//                                cell.setCellValue(stu.getC4());
//                            } else if (j ==9) {
//                                cell.setCellValue(stu.getC5());
//                            } else if (j ==10) {
//                                cell.setCellValue(stu.getC6());
//                            } else if (j ==11) {
//                                cell.setCellValue(stu.getC7());
//                            } else if (j ==12) {
//                                cell.setCellValue(stu.getC8());
//                            } else if (j ==13) {
//                                cell.setCellValue(stu.getC9());
//                            } else if (j ==14) {
//                                cell.setCellValue(stu.getC10());
//                            } else if (j ==15) {
//                                cell.setCellValue(stu.getC11());
//                            } else if (j ==16) {
//                                cell.setCellValue(stu.getC12());
//                            } else if (j ==17) {
//                                cell.setCellValue(stu.getC13());
//                            } else if (j ==18) {
//                                cell.setCellValue(stu.getC14());
//                            } else if (j ==19) {
//                                cell.setCellValue(stu.getC15());
//                            } else if (j ==20) {
//                                cell.setCellValue(stu.getC16());
//                            } else if (j ==21) {
//                                cell.setCellValue(stu.getC17());
//                            } else if (j ==22) {
//                                cell.setCellValue(stu.getC18());
//                            }
//                        }
//            }
            //将整理好的excel数据写入流中
            wb.write(os);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                // 关闭输出流
                if (os != null) {
                    os.close();
                }
                sqlSession.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /*
        设置浏览器下载响应头
     */
    private static void setResponseHeader(HttpServletResponse response, String fileName) {
        try {
            try {
                fileName = new String(fileName.getBytes(), "ISO8859-1");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            response.setContentType("application/octet-stream;charset=UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
            response.addHeader("Pargam", "no-cache");
            response.addHeader("Cache-Control", "no-cache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}